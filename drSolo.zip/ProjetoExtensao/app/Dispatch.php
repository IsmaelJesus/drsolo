<?php


namespace App;


use Src\Classes\ClassRoutes;

class Dispatch extends ClassRoutes {

    #Atributos
    private $method;
    private $param = [];
    private $obj;

    #Método Construtor
    public function __construct(){
        self::addController();
    }

    #Método de adição de controller
    private function addController(){
        $rotaController = $this->getRota(); #Rota proveniente da classe ClassRoutes e método GetRota
        $nameS = "App\\Controller\\{$rotaController}";
        $this->obj = new $nameS;

        if(isset($this->parserUrl()[1])){
            self::addMethod();
        }
    }

    #Método de adição de método controller
    private function addMethod(){
        if(method_exists($this->obj,$this->parserUrl() [1])){
            $this->setMethod("{$this->parserUrl()[1]}");
            self::addParam();
            call_user_func_array([$this->obj,$this->getMethod()],$this->getParam());
        }else{

        }
    }

    #Método de adição de parâmetros do controller
    private function addParam(){
        $countArray = count($this->parserUrl());

        if($countArray > 2){
            foreach ($this->parserUrl() as $key => $value){
                if($key > 1){
                    $this->setParam($this-> param += [$key => $value]);
                }
            }
        }
    }

    protected function getMethod(){
        return $this->method;
    }

    public function setMethod($method){
        $this->method = $method;
    }

    protected function getParam(){
        return $this->param;
    }

    public function setParam($param){
        $this->param = $param;
    }
}