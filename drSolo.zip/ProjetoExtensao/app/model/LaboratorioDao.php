<?php

namespace App\Controller;

use App\Model\Conexao;
use App\Controller\Laboratorio;

class LaboratorioDao extends Conexao {
    public function inserir(Laboratorio $c){
        $sql = 'INSERT INTO clientes (nome,email,senha,telefone) VALUES (?,?,?,?)';

        $stmt = Conexao::getConn()->prepare($sql);

        $stmt->bindValue(1,$c->getNome());
        $stmt->bindValue(2,$c->getEmail());
        $stmt->bindValue(4,$c->getTelefone());
        $stmt->execute();
    }

    public function read(){
        $sql = 'SELECT * FROM clientes';

        $stmt = Conexao::getConn()->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }
}
