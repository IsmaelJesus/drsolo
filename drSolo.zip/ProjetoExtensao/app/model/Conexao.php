<?php

namespace App\Model;

class Conexao{

    private static $instance;

    public function getConn(){ //Verifica se já uma conexão aberta com o banco de dados
        try{
            if(!isset(self::$instance)){
                self::$instance = new \PDO("mysql:host=".HOST.";dbname=".DB.";charset=utf8",USER,PASS);
            }

            return self::$instance;
        }catch (\PDOException $e){
            return $e->getMessage();
        }
    }
}