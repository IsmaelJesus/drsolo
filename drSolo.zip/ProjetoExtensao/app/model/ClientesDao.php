<?php

namespace App\Model;

class ClientesDao extends Conexao{

    public function inserir(Clientes $c){
        $sql = 'INSERT INTO clientes (nome,email,senha,telefone) VALUES (?,?,?,?)';

        $stmt = Conexao::getConn()->prepare($sql);

        $stmt->bindValue(1,$c->getNome());
        $stmt->bindValue(2,$c->getEmail());
        $stmt->bindValue(3,$c->getSenha());
        $stmt->bindValue(4,$c->getTelefone());
        $stmt->execute();
    }

    public function read(){
        $sql = 'SELECT * FROM clientes';

        $stmt = Conexao::getConn()->prepare($sql);
        $stmt->execute();
    }

    public function atualiza(Clientes $c){

    }

    public function deleta($id){

    }

    public function busca($email){
        $sql = "SELECT * FROM clientes WHERE email = ?";
        $Cfetch = $stmt = Conexao::getConn()->prepare($sql);
        $Cfetch->bindParam(1,$email);
        $Cfetch->execute();

        $resul = $Cfetch->fetch(\PDO::FETCH_ASSOC);
        return $resul;
    }
}