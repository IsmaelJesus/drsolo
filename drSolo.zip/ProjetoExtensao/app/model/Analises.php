<?php

namespace App\Model;

class Analises{
    private $cod_analise;
    private $cod_cliente;
    private $cod_lab;
    private $data_analise;
    private $nome;
    private $ph_agua;
    private $ph_cacl2;
    private $m_o;
    private $c_o;
    private $p;
    private $k;
    private $ca;
    private $mg;
    private $s;
    private $zn;
    private $b;
    private $cu;
    private $fe;
    private $mn;
    private $al;
    private $ctc;
    private $h_al;
    private $v;
    private $m;
    private $argila;
    private $silte;
    private $areia;

    public function getCodAnalise(){
        return $this->cod_analise;
    }

    public function setCodAnalise($cod_analise){
        $this->cod_analise = $cod_analise;
    }

    public function getCodCliente(){
        return $this->cod_cliente;
    }

    public function setCodCliente($cod_cliente){
        $this->cod_cliente = $cod_cliente;
    }

    public function getCodLab(){
        return $this->cod_lab;
    }

    public function setCodLab($cod_lab){
        $this->cod_lab = $cod_lab;
    }

    public function getDataAnalise(){
        return $this->data_analise;
    }

    public function setDataAnalise($data_analise){
        $this->data_analise = $data_analise;
    }

    public function getNome()
    {
        return $this->nome;
    }

    public function setNome($nome)
    {
        $this->nome = $nome;
    }

    public function getPhAgua(){
        return $this->ph_agua;
    }

    public function setPhAgua($ph_agua){
        $this->ph_agua = $ph_agua;
    }

    public function getPhCacl2(){
        return $this->ph_cacl2;
    }

    public function setPhCacl2($ph_cacl2){
        $this->ph_cacl2 = $ph_cacl2;
    }

    public function getMO(){
        return $this->m_o;
    }

    public function setMO($m_o){
        $this->m_o = $m_o;
    }

    public function getCO()
    {
        return $this->c_o;
    }

    public function setCO($c_o)
    {
        $this->c_o = $c_o;
    }

    public function getP(){
        return $this->p;
    }

    public function setP($p){
        $this->p = $p;
    }

    public function getK(){
        return $this->k;
    }

    public function setK($k){
        $this->k = $k;
    }

    public function getCa(){
        return $this->ca;
    }

    public function setCa($ca){
        $this->ca = $ca;
    }

    public function getMg(){
        return $this->mg;
    }

    public function setMg($mg){
        $this->mg = $mg;
    }

    public function getS(){
        return $this->s;
    }

    public function setS($s){
        $this->s = $s;
    }

    public function getZn(){
        return $this->zn;
    }

    public function setZn($zn){
        $this->zn = $zn;
    }

    public function getB(){
        return $this->b;
    }

    public function setB($b){
        $this->b = $b;
    }

    public function getCu(){
        return $this->cu;
    }

    public function setCu($cu){
        $this->cu = $cu;
    }

    public function getFe(){
        return $this->fe;
    }

    public function setFe($fe){
        $this->fe = $fe;
    }

    public function getMn(){
        return $this->mn;
    }

    public function setMn($mn){
        $this->mn = $mn;
    }

    public function getAl()
    {
        return $this->al;
    }

    public function setAl($al)
    {
        $this->al = $al;
    }

    public function getCtc()
    {
        return $this->ctc;
    }

    public function setCtc($ctc)
    {
        $this->ctc = $ctc;
    }

    public function getHAl()
    {
        return $this->h_al;
    }

    public function setHAl($h_al)
    {
        $this->h_al = $h_al;
    }

    public function getV()
    {
        return $this->v;
    }

    public function setV($v)
    {
        $this->v = $v;
    }

    public function getM()
    {
        return $this->m;
    }

    public function setM($m)
    {
        $this->m = $m;
    }

    public function getArgila()
    {
        return $this->argila;
    }

    public function setArgila($argila)
    {
        $this->argila = $argila;
    }

    public function getSilte()
    {
        return $this->silte;
    }

    public function setSilte($silte)
    {
        $this->silte = $silte;
    }

    public function getAreia()
    {
        return $this->areia;
    }

    public function setAreia($areia)
    {
        $this->areia = $areia;
    }
}