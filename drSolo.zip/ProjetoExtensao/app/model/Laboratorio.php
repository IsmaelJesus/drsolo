<?php

namespace App\Controller;

class Laboratorio{
    private $cod_lab;
    private $nome;
    private $email;
    private $telefone;

    public function getCodLab(){
        return $this->cod_lab;
    }

    public function setCodLab($cod_lab){
        $this->cod_lab = $cod_lab;
    }

    public function getNome(){
        return $this->nome;
    }

    public function setNome($nome){
        $this->nome = $nome;
    }

    public function getEmail(){
        return $this->email;
    }

    public function setEmail($email){
        $this->email = $email;
    }

    public function getTelefone(){
        return $this->telefone;
    }

    public function setTelefone($telefone){
        $this->telefone = $telefone;
    }
}