<?php


namespace App\Model;

use App\Model\Conexao;
use App\Model\Analises;

class AnalisesDao extends Conexao{
    public function inserir(Analises $d){
        $sql = 'INSERT INTO analises (cod_cliente,cod_lab,data_analise,nome_analise,ph_agua,ph_cacl2,m_o,c_o,p,k,ca,mg,s,zn,b,cu,fe,mn,al,ctc,h_al,v,m,argila,silte,areia) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';

        $stmt = Conexao::getConn()->prepare($sql);

        $stmt->bindValue(1,$d->getCodCliente());
        $stmt->bindValue(2,$d->getCodLab());
        $stmt->bindValue(3,$d->getDataAnalise());
        $stmt->bindValue(4,$d->getNome());
        $stmt->bindValue(5,$d->getPhAgua());
        $stmt->bindValue(6,$d->getPhCacl2());
        $stmt->bindValue(7,$d->getMO());
        $stmt->bindValue(8,$d->getCO());
        $stmt->bindValue(9,$d->getP());
        $stmt->bindValue(10,$d->getK());
        $stmt->bindValue(11,$d->getCa());
        $stmt->bindValue(12,$d->getMg());
        $stmt->bindValue(13,$d->getS());
        $stmt->bindValue(14,$d->getZn());
        $stmt->bindValue(15,$d->getB());
        $stmt->bindValue(16,$d->getCu());
        $stmt->bindValue(17,$d->getFe());
        $stmt->bindValue(18,$d->getMn());
        $stmt->bindValue(19,$d->getAl());
        $stmt->bindValue(20,$d->getCtc());
        $stmt->bindValue(21,$d->getHAl());
        $stmt->bindValue(22,$d->getV());
        $stmt->bindValue(23,$d->getM());
        $stmt->bindValue(24,$d->getArgila());
        $stmt->bindValue(25,$d->getSilte());
        $stmt->bindValue(26,$d->getAreia());
        $stmt->execute();
    }

    public function busca($codUsuario){
        $sql = "SELECT * FROM analises WHERE cod_cliente = ?";
        $stmt = Conexao::getConn()->prepare($sql);
        $stmt->bindValue(1,$codUsuario);
        $stmt->execute();

        $resul = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        return $resul;
    }

    public function buscaCod($cod){
        $sql = "SELECT * FROM analises WHERE cod_analise = ?";
        $Cfetch = $stmt = Conexao::getConn()->prepare($sql);
        $Cfetch->bindParam(1,$cod);
        $Cfetch->execute();

        $resul = $Cfetch->fetch(\PDO::FETCH_ASSOC);
        return $resul;
    }

    public function atualizar(Analises $a){
        $sql = "UPDATE analises SET data_analise = ?,nome_analise = ?,ph_agua = ?,ph_cacl2 = ?,m_o = ?,c_o = ?,p = ?,k = ?,ca = ?,mg = ?,s = ?,zn = ?,b = ?,cu = ?,fe = ?,mn = ?,al = ?,ctc = ?,h_al = ?,v = ?,m = ?,argila = ?,silte = ?,areia = ? WHERE cod_analise = ?";
        $stmt = Conexao::getConn()->prepare($sql);
        $stmt->bindValue(1,$a->getDataAnalise());
        $stmt->bindValue(2,$a->getNome());
        $stmt->bindValue(3,$a->getPhAgua());
        $stmt->bindValue(4,$a->getPhCacl2());
        $stmt->bindValue(5,$a->getMO());
        $stmt->bindValue(6,$a->getCO());
        $stmt->bindValue(7,$a->getP());
        $stmt->bindValue(8,$a->getK());
        $stmt->bindValue(9,$a->getCa());
        $stmt->bindValue(10,$a->getMg());
        $stmt->bindValue(11,$a->getS());
        $stmt->bindValue(12,$a->getZn());
        $stmt->bindValue(13,$a->getB());
        $stmt->bindValue(14,$a->getCu());
        $stmt->bindValue(15,$a->getFe());
        $stmt->bindValue(16,$a->getMn());
        $stmt->bindValue(17,$a->getAl());
        $stmt->bindValue(18,$a->getCtc());
        $stmt->bindValue(19,$a->getHAl());
        $stmt->bindValue(20,$a->getV());
        $stmt->bindValue(21,$a->getM());
        $stmt->bindValue(22,$a->getArgila());
        $stmt->bindValue(23,$a->getSilte());
        $stmt->bindValue(24,$a->getAreia());
        $stmt->bindValue(25,$a->getCodAnalise());
        $stmt->execute();
    }

    public function deletar($cod){
        $sql = "DELETE FROM analises WHERE cod_analise = ?";
        $stmt = Conexao::getConn()->prepare($sql);
        $stmt->bindParam(1,$cod);
        $stmt->execute();
    }
}