<?php


namespace App\Controller;
session_start();

use App\Model\Clientes;
use App\Model\ClientesDao;
use Cassandra\Session;
use Src\Classes\ClassRender;
use Src\Interfaces\InterfaceView;

class ControllerLogin extends ClassRender Implements InterfaceView {

    protected $email;
    protected $senha;

    public function __construct(){
        $this->setTitle("Realize Seu Login");
        $this->setType("cliente");
        $this->setDescription("Pagina para realizar login");
        $this->setKeywords("Analise de Solo, IFNMG");
        $this->setDir("login/");
        $this->renderLayout();
    }

    public function recVariaveis(){
        if(!isset($_POST['email'])){
            return -1;
        }else if(!isset($_POST['senha'])){
            return -1;
        }else{
            $this->email = filter_input(INPUT_POST,'email',FILTER_SANITIZE_SPECIAL_CHARS);
            $this->senha = filter_input(INPUT_POST,'senha',FILTER_SANITIZE_SPECIAL_CHARS);
            return 1;
        }
    }

    public function autentica(){
        if($this->recVariaveis() > 0){
            $cliDao = new ClientesDao();
            $dados = $cliDao->busca($this->email);
            if(count($dados) > 0){
                if(($dados['senha'] == $this->senha)){
                    $_SESSION['isLogado'] = true;
                    $_SESSION['codUsuario'] = $dados['cod_cliente'];
                    header('Location: '.DIRPAGE.'painel/exibe');
                }else{
                    header('Location: '.DIRPAGE.'login');
                }
            }
        }
    }

    public function logOut(){
        unset($_SESSION['isLogado']);
        header('Location: '.DIRPAGE.'login');
    }
}