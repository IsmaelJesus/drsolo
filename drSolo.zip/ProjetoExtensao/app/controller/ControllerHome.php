<?php

namespace App\Controller;

use App\Model\Analises;
use Src\Classes\ClassRender;
use Src\Interfaces\InterfaceView;

class ControllerHome Extends ClassRender implements InterfaceView {
    public function __construct(){
        $this->setTitle("Editar Analises");
        $this->setType("cliente");
        $this->setDescription("Projeto Dr. Solo");
        $this->setKeywords("Analise de Solo, IFNMG");
        $this->setDir("home/");
        $this->renderLayout();
    }

    public function recebeVariaveis(){
        $ana = new Analises();
        $ana->setCodAnalise(0);
        $ana->setCodCliente(1);
        $ana->setCodLab(1);
        if(isset($_POST['data'])){
            $ana->setDataAnalise($_POST['data']);
        }
        if(isset($_POST['phagua'])){
            $ana->setPhAgua(filter_input(INPUT_POST,'phagua',FILTER_SANITIZE_SPECIAL_CHARS));
        }
        if(isset($_POST['phcacl2'])){
            $ana->setPhCacl2(filter_input(INPUT_POST,'cacl2',FILTER_SANITIZE_SPECIAL_CHARS));
        }
        if(isset($_POST['mo'])){
            $ana->setMO(filter_input(INPUT_POST,'mo',FILTER_SANITIZE_SPECIAL_CHARS));
        }
        if(isset($_POST['p'])) {
            $ana->setP(filter_input(INPUT_POST, 'p', FILTER_SANITIZE_SPECIAL_CHARS));
        }
        if(isset($_POST['k'])) {
            $ana->setK(filter_input(INPUT_POST, 'k', FILTER_SANITIZE_SPECIAL_CHARS));
        }
        if(isset($_POST['ca'])) {
            $ana->setCa(filter_input(INPUT_POST, 'ca', FILTER_SANITIZE_SPECIAL_CHARS));
        }
        if(isset($_POST['mg'])) {
            $ana->setMg(filter_input(INPUT_POST, 'mg', FILTER_SANITIZE_SPECIAL_CHARS));
        }
        if(isset($_POST['s'])) {
            $ana->setS(filter_input(INPUT_POST, 's', FILTER_SANITIZE_SPECIAL_CHARS));
        }
        if(isset($_POST['zn'])) {
            $ana->setZn(filter_input(INPUT_POST, 'zn', FILTER_SANITIZE_SPECIAL_CHARS));
        }
        if(isset($_POST['b'])) {
            $ana->setB(filter_input(INPUT_POST, 'b', FILTER_SANITIZE_SPECIAL_CHARS));
        }
        if(isset($_POST['cu'])) {
            $ana->setCu(filter_input(INPUT_POST, 'cu', FILTER_SANITIZE_SPECIAL_CHARS));
        }
        if(isset($_POST['fe'])) {
            $ana->setFe(filter_input(INPUT_POST, 'fe', FILTER_SANITIZE_SPECIAL_CHARS));
        }
        if(isset($_POST['mn'])) {
            $ana->setMn(filter_input(INPUT_POST, 'mn', FILTER_SANITIZE_SPECIAL_CHARS));
        }
        if(isset($_POST['al'])) {
            $ana->setAl(filter_input(INPUT_POST, 'al', FILTER_SANITIZE_SPECIAL_CHARS));
        }
        if(isset($_POST['arg'])) {
            $ana->setArgila(filter_input(INPUT_POST, 'arg', FILTER_SANITIZE_SPECIAL_CHARS));
        }
        if(isset($_POST['sil'])) {
            $ana->setSilte(filter_input(INPUT_POST, 'sil', FILTER_SANITIZE_SPECIAL_CHARS));
        }
        if(isset($_POST['are'])) {
            $ana->setAreia(filter_input(INPUT_POST, 'are', FILTER_SANITIZE_SPECIAL_CHARS));
        }

        return $ana;
    }
}
