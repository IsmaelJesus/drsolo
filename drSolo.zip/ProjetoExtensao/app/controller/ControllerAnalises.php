<?php


namespace App\Controller;


use App\Model\Analises;
use Src\Classes\ClassRender;
use Src\Interfaces\InterfaceView;
use App\Model\AnalisesDao;

class ControllerAnalises extends ClassRender implements InterfaceView {
    public function __construct(){
        $this->setTitle("Analises");
        $this->setType("cliente");
        $this->setDescription("Visualize suas Analises cadastradass");
        $this->setKeywords("Analise de Solo, IFNMG");
        $this->setDir("analises/");
        $this->renderLayout();
    }

    public function exibeAnalises(){
        session_start();
        $analisesDao = new AnalisesDao();
        $codUsuario = $_SESSION['codUsuario'];
        $busca = $analisesDao->busca($codUsuario);

        echo "<div class='container-fluid'>";
            echo "<div class='row justify-content-center'>";
                echo "<div class='col-sm-12 col-md-9 mb-3'>";
                    echo "<table class='table'>";
                        echo "<thead>";
                            echo "<tr>";
                                echo "<th scope='col'>Nome</th>";
                                echo "<th scope='col'>Data</th>";
                                echo "<th scope='col'>Ações</th>";
                            echo "</tr>";
                        echo "</thead>";
                        echo "<tbody>";
                            foreach($busca as $key => $v){
                                $cData = new \DateTime($v['data_analise']);
                                echo "<tr>";
                                echo "<th>".$v['nome_analise']."</th>";
                                echo "<th>".$cData->format('d-m-Y')."</th>";
                                echo "<th>"."<a href='".DIRPAGE."editarAnalises?cod=$v[cod_analise]'>Editar | </a>"."<a href='".DIRPAGE."analises/deletar?cod=$v[cod_analise]'>Excluir</a>"."</th>";
                                echo "</tr>";
                            }
                        echo "</tbody>";
                    echo "</table>";
                echo "</div>";
            echo "</div>";
        echo "</div>";
    }

    public function deletar(){
        if(isset($_GET['cod'])){
            $deletar = new AnalisesDao();
            $deletar->deletar($_GET['cod']);
            header('location: http://localhost/ProjetoExtensao/analises/exibeAnalises');
        }else{
            header('location: http://localhost/ProjetoExtensao/analises/exibeAnalises');
        }
    }
}