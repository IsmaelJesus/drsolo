<?php

namespace App\Controller;

class ControllerSiteMap{
    public function  testeMetodo($par){
        echo "Parametro: {$par}";
    }
}
