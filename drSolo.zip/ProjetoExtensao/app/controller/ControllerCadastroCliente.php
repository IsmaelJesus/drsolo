<?php


namespace App\Controller;


use App\Model\Clientes;
use App\Model\ClientesDao;
use Src\Classes\ClassRender;
use Src\Interfaces\InterfaceView;

class ControllerCadastroCliente extends ClientesDao {
    public function __construct(){
        $rd = new ClassRender();
        $rd->setTitle("Cadastre-se");
        $rd->setType("cliente");
        $rd->setDescription("Faça seu cadastro para começar a utilizar o Dr. Solo");
        $rd->setKeywords("Analise de Solo, IFNMG, Cadastro Clientes");
        $rd->setDir("cadastroCliente/");
        $rd->renderLayout();
    }

    #Função para receber variaveis do formulário
    public function recebeVariaveis(){
        if(isset($_POST['nome'])){
            $cli->setNome(filter_input(INPUT_POST,'nome',FILTER_SANITIZE_SPECIAL_CHARS));
        }
        if(isset($_POST['email'])){
            $cli->setEmail(filter_input(INPUT_POST,'email',FILTER_SANITIZE_SPECIAL_CHARS));
        }
        if(isset($_POST['senhap'])){
            $cli->setSenha(filter_input(INPUT_POST,'senhap',FILTER_SANITIZE_SPECIAL_CHARS));
        }
        if(isset($_POST['telefone'])) {
            $cli->setTelefone(filter_input(INPUT_POST, 'telefone', FILTER_SANITIZE_SPECIAL_CHARS));
        }

        return $cli;
    }

    #Chama o método cadastro
    public function cadastrar(){
        $cli = new Clientes();
        $cli = $this->recebeVariaveis();
        parent::inserir($cli);
    }
}