<?php

namespace App\Controller;

class Controller404{
    public function __construct(){
        echo "<h1>Página não encontrada</h1>";
    }
}
