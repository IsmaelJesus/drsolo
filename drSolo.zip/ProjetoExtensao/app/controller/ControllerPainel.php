<?php


namespace App\Controller;


use App\Model\AnalisesDao;
use Src\Classes\ClassRender;
use Src\Interfaces\InterfaceView;

class ControllerPainel extends ClassRender implements InterfaceView {
    public function __construct(){
        session_start();
        $codCliente = $_SESSION['codUsuario'];
        $analisesDao = new AnalisesDao();
        $busca = $analisesDao->busca($codCliente);
        $this->setArray($busca);
        $this->setTitle("Painel");
        $this->setType("cliente");
        $this->setDescription("Cadastre e Analise suas Analises");
        $this->setKeywords("Analise de Solo, IFNMG");
        $this->setDir("painel/");
        $this->renderLayout();
    }

    public function recVariaveis(){
        if(isset($_POST['analise'])){
            return $_POST['analise'];
        }else{
            return 0;
        }
    }

    public function exibe(){
        $cod = $this->recVariaveis();
        $analisesDao = new AnalisesDao();

        $busca = $analisesDao->buscaCod($cod);
        $campos = array(
            array("titulo" => "Avaliação do Ph", "nomeClasse" => "phAgua"),
            array("titulo" => "Avaliação do Ph em CaCl2", "nomeClasse" => "phCacl2"),
            array("titulo" => "Avaliação da Matéria Orgânica", "nomeClasse" => "mo"),
            array("titulo" => "Avaliação do Fósforo", "nomeClasse" => "p"),
            array("titulo" => "Avaliação do Potássio", "nomeClasse" => "k"),
            array("titulo" => "Avaliação do Cálcio", "nomeClasse" => "ca"),
            array("titulo" => "Avaliação do Magnésio", "nomeClasse" => "mg"),
            array("titulo" => "Avaliação do Enxofre", "nomeClasse" => "s"),
            array("titulo" => "Avaliação do Zinco", "nomeClasse" => "zn"),
            array("titulo" => "Avaliação do Boro", "nomeClasse" => "b"),
            array("titulo" => "Avaliação do Cobre", "nomeClasse" => "cu"),
            array("titulo" => "Avaliação do Ferro", "nomeClasse" => "fe"),
            array("titulo" => "Avaliação do Manganês", "nomeClasse" => "mn"),
            array("titulo" => "Avaliação do Alumínio", "nomeClasse" => "al"),
            array("titulo" => "Avaliação do H + Al", "nomeClasse" => "h_al"),
            array("titulo" => "Avaliação do V", "nomeClasse" => "v")
        );

        require '../src/includes/configuracao_medidores/ph_agua.php';
        require '../src/includes/configuracao_medidores/phcacl2.php';
        require '../src/includes/configuracao_medidores/mo.php';
        //Comparações para saber qual medidor de fósforo ele irá utilizar, de acordo com a quantidade de argila
        if($busca['argila'] >= 0   && $busca['argila'] <= 15) {
            require '../src/includes/configuracao_medidores/p0_15.php';
        }else if($busca['argila'] >= 15   && $busca['argila'] <= 35) {
            require '../src/includes/configuracao_medidores/p0_15.php';
        }else if($busca['argila'] >= 35   && $busca['argila'] <= 60) {
            require '../src/includes/configuracao_medidores/p0_15.php';
        }else{
            require '../src/includes/configuracao_medidores/p0_15.php';
        }
        require '../src/includes/configuracao_medidores/k.php';
        require '../src/includes/configuracao_medidores/ca.php';
        require '../src/includes/configuracao_medidores/mg.php';
        require '../src/includes/configuracao_medidores/s.php';
        require '../src/includes/configuracao_medidores/zn.php';
        require '../src/includes/configuracao_medidores/b.php';
        require '../src/includes/configuracao_medidores/cu.php';
        require '../src/includes/configuracao_medidores/fe.php';
        require '../src/includes/configuracao_medidores/mn.php';
        require '../src/includes/configuracao_medidores/al.php';
        require '../src/includes/configuracao_medidores/h_al.php';
        require '../src/includes/configuracao_medidores/v.php';

        if($cod > 0) {
            echo "<div class='container-fluid'>";

            echo "<div class='row justify-content-center'>";
                echo "<div class='col-sm-12 col-md-5 mb-3'>";
                    echo "<div class='card'>";
                        echo "<div class='card-header'>";
                        echo "Tipo de solo";
                        echo "</div>";
                        echo "<div class='card-body'>";
                            echo "<div class='card-text'>";
                                if($busca['argila'] >= 0   && $busca['argila'] <= 15) {
                                    echo 'Arenoso';
                                }else if($busca['argila'] >= 15   && $busca['argila'] <= 35) {
                                    echo 'Siltoso';
                                }else if($busca['argila'] >= 35   && $busca['argila'] <= 60) {
                                    echo 'Argiloso';
                                }else{
                                    echo 'Muito Argiloso';
                                }
                            echo "</div>";
                    echo "</div>";
                echo "</div>";
            echo "</div>";

            echo "<div class='row justify-content-center'>";
            foreach ($campos as $value) {
                echo "<div class='col-sm-12 col-md-5 mb-3'>";
                echo    "<div class='card card-Medidas'>";
                echo        "<div class='card-header'>";
                echo        $value['titulo'];
                echo        "</div>";
                echo        "<div class='card-body'>";
                echo            "<div class='card-text colorText'>";
                echo                "<div id='$value[nomeClasse]' class='chart-style'>FusionCharts XT will load here!</div>";
                echo            "</div>";
                echo        "</div>";
                echo    "</div>";
                echo "</div>";
            }
            echo "</div>";
            echo "</div>";
        }else{
            echo "<div class='alert alert-danger col-8 mx-auto'>";
            echo "<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>";
            echo "<span>Por Favor Selecione uma analise no campo acima ! ou <a href='#' class='alert-link'>clique aqui</a> para cadastrar uma analise.</span>";
            echo "</div>";
        }
    }
}