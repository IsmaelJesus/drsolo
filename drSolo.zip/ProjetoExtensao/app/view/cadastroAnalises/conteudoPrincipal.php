<div class="container">
    <form method="POST" action="<?php echo DIRPAGE.'cadastroAnalises/cadastrar'?>">
        <div class="form-row">
            <div class="col-md-5 mx-auto mb-3">
                <label for="data">Data da Análise</label>
                <input type="date" class="form-control" id="data" name="data" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="nome">Nome da Análise</label>
                <input type="text" class="form-control" id="nome" name="nome" placeholder="Nome da Ánalise" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="phagua">Ph Água</label>
                <input type="text" class="form-control" id="phagua" name="phagua" placeholder="Ph Água" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="phcacl2">Ph CaCl2</label>
                <input type="text" class="form-control" id="phcacl2" name="phcacl2" placeholder="Ph CaCl2">
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="mo">M O</label>
                <input type="text" class="form-control" id="mo" name="mo" placeholder="Máteria Orgânica" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="co">C O</label>
                <input type="text" class="form-control" id="co" name="co" placeholder="Composto Orgânico" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="p">P</label>
                <input type="text" class="form-control" id="p" name="p" placeholder="Fósforo" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="k">K</label>
                <input type="text" class="form-control" id="k" name="k" placeholder="Potássio" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="ca">Ca</label>
                <input type="text" class="form-control" id="ca" name="ca" placeholder="Cálcio" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="mg">Mg</label>
                <input type="text" class="form-control" id="mg" name="mg" placeholder="Magnésio" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="s">S</label>
                <input type="text" class="form-control" id="s" name="s" placeholder="Enxofre" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="zn">Zn</label>
                <input type="text" class="form-control" id="zn" name="zn" placeholder="Zinco" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="b">B</label>
                <input type="text" class="form-control" id="b" name="b" placeholder="Boro" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="cu">Cu</label>
                <input type="text" class="form-control" id="cu" name="cu" placeholder="Cobre" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="fe">Fe</label>
                <input type="text" class="form-control" id="fe" name="fe" placeholder="Ferro" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="mn">Mn</label>
                <input type="text" class="form-control" id="mn" name="mn" placeholder="Manganês" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="al">Al</label>
                <input type="text" class="form-control" id="al" name="al" placeholder="Alumínio" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="ctc">CTC</label>
                <input type="text" class="form-control" id="ctc" name="ctc" placeholder="CTC" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="hal">H+Al</label>
                <input type="text" class="form-control" id="hal" name="hal" placeholder="H+Al" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="v">V</label>
                <input type="text" class="form-control" id="v" name="v" placeholder="V" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="m">M</label>
                <input type="text" class="form-control" id="m" name="m" placeholder="M" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="arg">Argila</label>
                <input type="text" class="form-control" id="arg" name="arg" placeholder="Argila" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="sil">Silte</label>
                <input type="text" class="form-control" id="sil" name="sil" placeholder="Silte" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="Are">Areia</label>
                <input type="text" class="form-control" id="are" name="are" placeholder="Areia" required>
            </div>
        </div>
        <div class="form-row">
            <button class="btn btn-primary d.block mx-auto" type="submit">Cadastrar Análises</button>
        </div>
    </form>
</div>