<div class="wrapper">
    <nav class="sidebar">
        <div class="sidebar_header">
            <img src="<?php echo DIRIMG.'icone_solo.png'?>" alt="">
            <h1>Dr. Solo</h1>
        </div>
        <ul class="sidebar_menu">
            <li class="active item_menu"><a href="<?php echo DIRPAGE.'painel'; ?>" class="link_menu"><span data-feather="home" class="feather-icon"></span>Inicio</a></li>
            <li class="item_menu"><a href="<?php echo DIRPAGE.'analises/exibeAnalises'; ?>" class="link_menu"><span data-feather="trending-up" class="feather-icon"></span>Análises</a></li>
            <div class="btn"><a href="<?php echo DIRPAGE.'login/logOut'?>" class="btn btn_sair">Sair</a></div>
        </ul>
    </nav>
    <div class="conteudo_principal">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">

                <button type="button" id="sidebarCollapse" class="btn btn-info">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>

            </div>
        </nav> <!-- Fim Barra Navegação-->

        <!--Conteudo Principal-->
        <div class="container-fluid">
        <?php
            include_once('conteudoPrincipal.php');
        ?>
        </div>
    </div>
</div>