

<!--d3-->
<!--<script type="text/javascript" src="https://mbostock.github.com/d3/d3.js?1.27.1"></script>
<script type="text/javascript" src="<?php echo DIRJS.'medidores.js';?>"></script>-->
<!-- Include fusioncharts core library -->
<script type="text/javascript" src="https://cdn.fusioncharts.com/fusioncharts/latest/fusioncharts.js"></script>
<!-- Include fusion theme -->
<script type="text/javascript" src="https://cdn.fusioncharts.com/fusioncharts/latest/themes/fusioncharts.theme.fusion.js"></script>
<script src="https://unpkg.com/jquery-fusioncharts@1.1.0/dist/fusioncharts.jqueryplugin.js"></script>

<script src="<?php echo DIRJS.'menu.js';?>"></script>
<script src="<?php echo DIRJS.'fusion.js';?>"></script>


<script>
    //Adiciona os icones na página
    feather.replace();
</script>
</body>
</html>