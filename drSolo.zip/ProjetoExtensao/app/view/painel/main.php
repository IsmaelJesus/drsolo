<div class="wrapper">
    <nav class="sidebar">
        <div class="sidebar_header">
            <img src="<?php echo DIRIMG.'icone_solo.png'?>" alt="Logo_Site">
            <h1>Dr. Solo</h1>
        </div>
        <ul class="sidebar_menu">
            <li class="active item_menu"><a href="<?php echo DIRPAGE.'painel'; ?>" class="link_menu"><span data-feather="home" class="feather-icon"></span>Inicio</a></li>
            <li class="item_menu"><a href="<?php echo DIRPAGE.'analises/exibeAnalises'; ?>" class="link_menu"><span data-feather="trending-up" class="feather-icon"></span>Análises</a></li>
            <!--<li class="item_menu"><a href="#" class="link_menu"><span data-feather="file-text" class="feather-icon"></span>Relatórios</a></li>-->
            <div class="btn"><a href="<?php echo DIRPAGE.'login/logOut'?>" class="btn btn_sair">Sair</a></div>
        </ul>
    </nav>
    <div class="conteudo_principal">
        <nav class="navbar navbar-expand-lg navbar-light d-flex bg-light justify-content-between">
            <div class="container-fluid">

                <button type="button" id="sidebarCollapse" class="btn btn-info">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                <form action="<?php echo DIRPAGE.'painel/exibe'; ?>" method="POST">
                    <div class="input-group">
                        <select name="analise" class="custom-select" id="inputGroupSelect04" aria-label="Example select with button addon">
                            <option selected>Escolha uma analise</option>
                            <?php
                            $array = $this->getArray();
                                foreach($array as &$key) {
                            ?>
                                    <option value="<?php echo $key['cod_analise']?>"><?php echo $key['nome_analise'];?></option>
                            <?php
                                }
                            ?>
                        </select>
                        <div class="input-group-append">
                            <button class="btn btn-info" type="submit">Realizar Análise</button>

                        </div>
                    </div>
                </form>
                <a href="<?php echo DIRPAGE.'cadastroAnalises';?>" class="btn btn-success">Cadastrar Análise</a>
            </div>
        </nav> <!-- Fim Barra Navegação-->

        <!--Conteudo Principal-->
        <div class="row justify-content-center">