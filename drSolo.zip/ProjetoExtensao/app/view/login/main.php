<div class="container">
    <div class="row  cardLogin justify-content-center d-flex">
        <div class="col-12 d-flex justify-content-center imgLogo">
            <h1 class="logoAnalise mt-4"><img src="<?php echo DIRIMG.'icone_solo.png';?>" alt="logo"></h1>
        </div>
        <div class="col-12 d-flex justify-content-center">
            <div class="card cardContent pb-3">
                <div class="card-header">
                    Realize Seu Login
                </div>
                <div class="card-body">
                    <form action="<?php echo DIRPAGE."login/autentica"?>" method="POST">
                        <div class="form-group">

                            <label for="exampleInputEmail1">Email</label>

                            <div class="inputContato">
                                <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="Digite seu email" autofocus="">
                            </div>

                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Senha</label>
                            <input type="password" class="form-control" id="senha" name="senha" placeholder="Digite sua senha">
                        </div>
                        <div class="form-group text-center">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="lembrar">
                                <label class="custom-control-label" for="lembrar">Lembrar</label>
                            </div>
                        </div>
                        <div class="footerCardLogin d-flex justify-content-between my-2">

                            <div class="d-flex">
                                <a href="<?php echo DIRPAGE.'cadastroCliente'?>" class="btn btn-info">Cadastre-se</a>
                            </div>

                            <div class="d-flex">
                                <button type="submit" class="btn btn-success">Entrar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <p class="text-left mt-2"><a href="<?php echo DIRPAGE; ?>">Voltar</a></p>
    </div>
</div>
