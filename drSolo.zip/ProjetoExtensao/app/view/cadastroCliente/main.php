<div class="container">
<div class="card bg-light">
    <article class="card-body mx-auto" style="max-width: 400px;">
        <form method="POST" action="<?php echo DIRPAGE.'cadastroCliente/cadastrar'?>">

            <div class="form-group input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"> <i class="fa fa-user"></i> </span>
                </div>
                <input name="nome" class="form-control" placeholder="Nome" type="text">
            </div> <!-- form-group// -->

            <div class="form-group input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"> <i class="fa fa-envelope"></i> </span>
                </div>
                <input name="email" class="form-control" placeholder="Email" type="email">
            </div> <!-- form-group// -->

            <div class="form-group input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
                </div>
                <input name="senhap" class="form-control" placeholder="Crie uma senha" type="password">
            </div> <!-- form-group// -->

            <div class="form-group input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
                </div>
                <input name="senhac" class="form-control" placeholder="Repita a senha" type="password">
            </div> <!-- form-group// -->

            <div class="form-group input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"> <i class="fa fa-phone"></i> </span>
                </div>
                <input name="telefone" class="form-control" placeholder="Telefone" type="text">
            </div> <!-- form-group// -->

            <div class="form-group">
                <button type="submit" class="btn btn-primary btn-block"> Cadastrar  </button>
            </div> <!-- form-group// -->
            <p class="text-center">Já tem uma conta ? <a href="<?php echo DIRPAGE.'login'?>">Entrar</a> </p>
        </form>
    </article>
</div> <!-- card.// -->

</div>
</div>
<!--container end.//-->