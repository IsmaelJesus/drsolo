<!--d3-->
<script type="text/javascript" src="https://mbostock.github.com/d3/d3.js?1.27.1"></script>
<script type="text/javascript" src="<?php echo DIRJS.'medidores.js';?>"></script>
<script src="<?php echo DIRJS.'menu.js';?>"></script>
<script>
    //Adiciona os icones na página
    feather.replace();
</script>