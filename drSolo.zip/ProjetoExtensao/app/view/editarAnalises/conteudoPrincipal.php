<div class="container">
    <?php
    $iten = $this->getArray();
    ?>
    <form method="POST" action="<?php echo DIRPAGE.'editarAnalises/editar'?>">
        <input type="hidden" name="cod" id="cod" value="<?php echo $_GET['cod']?>">
        <div class="form-row">
            <div class="col-md-5 mx-auto mb-3">
                <label for="data">Data da Análise</label>
                <input type="date" class="form-control" id="data" name="data" value="<?php echo $iten['data_analise'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="nome">Nome da Análise</label>
                <input type="text" class="form-control" id="nome" name="nome" placeholder="Nome da Ánalise" value="<?php echo $iten['nome_analise'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="phagua">Ph Água</label>
                <input type="text" class="form-control" id="phagua" name="phagua" placeholder="Ph Água"  value="<?php echo $iten['ph_agua'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="phcacl2">Ph CaCl2</label>
                <input type="text" class="form-control" id="phcacl2" name="phcacl2" placeholder="Ph CaCl2" value="<?php echo $iten['ph_cacl2'];?>">
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="mo">M O</label>
                <input type="text" class="form-control" id="mo" name="mo" placeholder="Máteria Orgânica" value="<?php echo $iten['m_o'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="co">C O</label>
                <input type="text" class="form-control" id="co" name="co" placeholder="Composto Orgânico" value="<?php echo $iten['c_o'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="p">P</label>
                <input type="text" class="form-control" id="p" name="p" placeholder="Fósforo" value="<?php echo $iten['p'];?>"required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="k">K</label>
                <input type="text" class="form-control" id="k" name="k" placeholder="Potássio" value="<?php echo $iten['k'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="ca">Ca</label>
                <input type="text" class="form-control" id="ca" name="ca" placeholder="Cálcio" value="<?php echo $iten['ca'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="mg">Mg</label>
                <input type="text" class="form-control" id="mg" name="mg" placeholder="Magnésio" value="<?php echo $iten['mg'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="s">S</label>
                <input type="text" class="form-control" id="s" name="s" placeholder="Enxofre" value="<?php echo $iten['s'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="zn">Zn</label>
                <input type="text" class="form-control" id="zn" name="zn" placeholder="Zinco" value="<?php echo $iten['zn'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="b">B</label>
                <input type="text" class="form-control" id="b" name="b" placeholder="Boro" value="<?php echo $iten['b'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="cu">Cu</label>
                <input type="text" class="form-control" id="cu" name="cu" placeholder="Cobre" value="<?php echo $iten['cu'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="fe">Fe</label>
                <input type="text" class="form-control" id="fe" name="fe" placeholder="Ferro" value="<?php echo $iten['fe'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="mn">Mn</label>
                <input type="text" class="form-control" id="mn" name="mn" placeholder="Manganês" value="<?php echo $iten['mn'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="al">Al</label>
                <input type="text" class="form-control" id="al" name="al" placeholder="Alumínio" value="<?php echo $iten['al'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="ctc">CTC</label>
                <input type="text" class="form-control" id="ctc" name="ctc" placeholder="CTC" value="<?php echo $iten['ctc'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="hal">H+Al</label>
                <input type="text" class="form-control" id="hal" name="hal" placeholder="H+Al" value="<?php echo $iten['h_al'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="v">V</label>
                <input type="text" class="form-control" id="v" name="v" placeholder="V" value="<?php echo $iten['v'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="m">M</label>
                <input type="text" class="form-control" id="m" name="m" placeholder="M" value="<?php echo $iten['m'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="arg">Argila</label>
                <input type="text" class="form-control" id="arg" name="arg" placeholder="Argila" value="<?php echo $iten['argila'];?>"  required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="sil">Silte</label>
                <input type="text" class="form-control" id="sil" name="sil" placeholder="Silte" value="<?php echo $iten['silte'];?>" required>
            </div>
            <div class="col-md-5 mx-auto mb-3">
                <label for="Are">Areia</label>
                <input type="text" class="form-control" id="are" name="are" placeholder="Areia" value="<?php echo $iten['areia'];?>" required>
            </div>
        </div>
        <div class="form-row">
            <button class="btn btn-primary d.block mx-auto" type="submit">Editar Análise</button>
        </div>
    </form>
</div>