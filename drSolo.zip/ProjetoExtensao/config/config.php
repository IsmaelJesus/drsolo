<?php

#Diretórios raízes

$PastaInterna = "ProjetoExtensao/"; //Será utilizado caso o site seja mudado pra uma pasta interna
define ('DIRPAGE',"http://{$_SERVER['HTTP_HOST']}/{$PastaInterna}");


//Vai comparar se o servidor colocou automaticamente a / após o fim da url fisica
if(substr($_SERVER['DOCUMENT_ROOT'],-1) == '/'){
    define('DIRREQ',"{$_SERVER['DOCUMENT_ROOT']}{$PastaInterna}");
}else{
    define('DIRREQ',"{$_SERVER['DOCUMENT_ROOT']}/{$PastaInterna}");
}

define('DIRIMG',DIRPAGE."public/images/");
define('DIRCSS',DIRPAGE."public/css/");
define('DIRJS',DIRPAGE."public/js/");

##Configurações do banco

define('HOST',"localhost");
define('DB',"drsolo");
define('USER',"root");
define('PASS',"");

