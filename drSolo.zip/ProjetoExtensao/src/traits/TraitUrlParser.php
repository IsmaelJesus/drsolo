<?php

namespace Src\Traits;

trait TraitUrlParser{
    #Divide a url em um Array, usando a barra como separador
    public function parserUrl(){
        return explode("/",rtrim($_GET['url']),FILTER_SANITIZE_URL);
    }
}
