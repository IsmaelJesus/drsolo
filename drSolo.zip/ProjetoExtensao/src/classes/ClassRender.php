<?php


namespace Src\Classes;


class ClassRender{
    private $dir; //diretorio da view que deseja buscar
    private $type;
    private $title;
    private $description;
    private $keywords;
    private $array;

    #Método Responsável por renderizar todo o layout
    public function renderLayout(){
        if($this->type == "admin"){
            include_once (DIRREQ.'app/view/layoutAdmin.php');
        }else {
            include_once(DIRREQ . 'app/view/layout.php');
        }
    }

    #Método responsável por caracteristicas especificas no head
    public function addHead(){
        if(file_exists(DIRREQ."app/view/{$this->getDir()}/head.php")){
            include(DIRREQ."app/view/{$this->getDir()}/head.php");
        }
    }

    #Método responsável por caracteristicas especificas no header
    public function addHeader(){
        if(file_exists(DIRREQ."app/view/{$this->getDir()}/header.php")){
            include(DIRREQ."app/view/{$this->getDir()}/header.php");
        }else{
            include(DIRREQ."app/view/header.php");
        }
    }

    #Método responsável por caracteristicas especificas no main
    public function addMain(){
        if(file_exists(DIRREQ."app/view/{$this->getDir()}/main.php")){
            include(DIRREQ."app/view/{$this->getDir()}/main.php");
        }
    }

    #Método responsável por caracteristicas especificas no footer
    public function addFooter(){
        if(file_exists(DIRREQ."app/view/{$this->getDir()}/footer.php")){
            include(DIRREQ."app/view/{$this->getDir()}/footer.php");
        }
    }

    public function getDir()
    {
        return $this->dir;
    }

    public function setDir($dir)
    {
        $this->dir = $dir;
    }

    public function getType()
    {
        return $this->type;
    }

    public function setType($type)
    {
        $this->type = $type;
    }

    public function getTitle()
    {
        return $this->title;
    }

    public function setTitle($title)
    {
        $this->title = $title;
    }

    public function getDescription()
    {
        return $this->description;
    }

    public function setDescription($description)
    {
        $this->description = $description;
    }

    public function getKeywords()
    {
        return $this->keywords;
    }

    public function setKeywords($keywords)
    {
        $this->keywords = $keywords;
    }

    /**
     * @return mixed
     */
    public function getArray()
    {
        return $this->array;
    }

    /**
     * @param mixed $array
     */
    public function setArray($array)
    {
        $this->array = $array;
    }
}