<?php

namespace Src\Classes;

use App\Controller\ControllerAnalises;
use Src\Traits\TraitUrlParser;

class ClassRoutes{
    use TraitUrlParser;

    private $rota;

    #Método de retorno da rota
    public function getRota(){
        $url = $this->parserUrl(); //pega o conteudo que esta na url
        $i = $url[0]; //Transforma esse conteudo em um array, pra chamar o controller responsável

        $this->rota = array( //Pega o array, e realiza a chamada dos controllers
            ""=>"ControllerHome",
            "home"=>"ControllerHome",
            "sitemap"=>"ControllerSiteMap",
            "login"=>"ControllerLogin",
            "painel" => "ControllerPainel",
            "cadastroCliente"=>"ControllerCadastroCliente",
            "cadastroAnalises" => "ControllerCadastroAnalises",
            "analises" => "ControllerAnalises",
            "editarAnalises" => "ControllerEditarAnalises"
        );

        if(array_key_exists($i,$this->rota)){
            if(file_exists(DIRREQ."app/controller/{$this->rota[$i]}.php")){
                return $this->rota[$i];
            }else{
                return "ControllerHome";
            }
        }else{
            return "Controller404";
        }
    }
}
