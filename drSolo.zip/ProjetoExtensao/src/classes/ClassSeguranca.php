<?php

namespace Src\Classes;

class ClassSeguranca{
    public function __construct(){
        if (!isset($_SESSION['isLogado'])) {
            header('location: ' . DIRPAGE . 'login');
        }
    }
}