<?php

namespace Src\Includes\Cafe;
use Src\Includes\FusionCharts;

$arrChartConfig = array(
    "chart" => array(
        "caption" => "Cu",
        //"numberSuffix" => "mg/dm3",
        "gaugefillmix" => "{dark-20},{light+70},{dark-10}",
        "theme" => "fusion"
    ),

    "colorrange" => array(
        "color" => [
          [
            "minvalue"=> "0",
            "maxvalue"=> "0.3",
            "label"=> "Muito Baixo",
            "code"=> "#FE0606"
          ],
          [
            "minvalue" => "0.4",
            "maxvalue" => "0.7",
            "label" => "Baixo",
            "code" => "#F79301"
          ],
          [
            "minvalue" => "0.8",
            "maxvalue" => "1.2",
            "label" => "Médio",
            "code" => "#FDCF02"
          ],
          [
            "minvalue" => "1.3",
            "maxvalue" => "1.8",
            "label" => "Bom",
            "code" => "#018233"
          ]
        ]
    ),

    "pointers" => array(
        "pointer" => [
            [
                "value" => $busca["cu"]
            ]
        ]
    )
);

$jsonEncodedData = json_encode($arrChartConfig);

$columnChart = new FusionCharts("hlineargauge", "Cu", "100%", 150, "cu", "json", $jsonEncodedData);

$columnChart->render();
?>