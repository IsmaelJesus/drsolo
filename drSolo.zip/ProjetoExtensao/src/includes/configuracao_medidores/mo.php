<?php

namespace Src\Includes\Cafe;
use Src\Includes\FusionCharts;

$arrChartConfig = array(
    "chart" => array(
        "caption" => "Mo",
        //"numberSuffix" => "dag/Kg",
        "gaugefillmix" => "{dark-20},{light+70},{dark-10}",
        "theme" => "fusion"
    ),

    "colorrange" => array(
        "color" => [
            [
                "minvalue"=> "0",
                "maxvalue"=> "0.7",
                "label"=> "Muito Baixo",
                "code"=> "#FE0606"
            ],
            [
                "minvalue" => "0.71",
                "maxvalue" => "2",
                "label" => "Baixo",
                "code" => "#F79301"
            ],
            [
                "minvalue" => "2.01",
                "maxvalue" => "4.0",
                "label" => "Médio",
                "code" => "#FDCF02"
            ],
            [
                "minvalue" => "4.01",
                "maxvalue" => "7.0",
                "label" => "Bom",
                "code" => "#018233"
            ]
        ]
    ),

    "pointers" => array(
        "pointer" => [
            [
                "value" => $busca["m_o"]
            ]
        ]
    )
);

$jsonEncodedData = json_encode($arrChartConfig);

$columnChart = new FusionCharts("hlineargauge", "Mo", "100%", 150, "mo", "json", $jsonEncodedData);

$columnChart->render();
?>