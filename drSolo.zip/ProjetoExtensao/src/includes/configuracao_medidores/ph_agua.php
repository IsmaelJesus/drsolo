<?php

namespace Src\Includes\Cafe;
use Src\Includes\FusionCharts;

$arrChartConfig = array(
    "chart" => array(
        "caption" => "Ph Água",
        "numberSuffix" => "",
        "gaugefillmix" => "{dark-20},{light+70},{dark-10}",
        "theme" => "fusion"
    ),

    "colorrange" => array(
        "color" => [
            [
                "minvalue"=> "0",
                "maxvalue"=> "4.5",
                "label"=> "Muito Baixo",
                "code"=> "#FE0606"
            ],
            [
                "minvalue" => "4.5",
                "maxvalue" => "5.4",
                "label" => "Baixo",
                "code" => "#F79301"
            ],
            [
                "minvalue" => "5.5",
                "maxvalue" => "6.0",
                "label" => "Bom",
                "code" => "#47CC56"
            ],
            [
                "minvalue" => "6.1",
                "maxvalue" => "7",
                "label" => "Alto",
                "code" => "#018233"
            ]
        ]
    ),

    "pointers" => array(
        "pointer" => [
            [
                "value" => $busca["ph_agua"]
            ]
        ]
    )
);

$jsonEncodedData = json_encode($arrChartConfig);


/*echo '<pre>';
print_r($jsonEncodedData);
echo '</pre>';*/

$columnChart = new FusionCharts("hlineargauge", "phA", "100%", 150, "phAgua", "json", $jsonEncodedData);

$columnChart->render();
?>