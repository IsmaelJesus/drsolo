<?php

namespace Src\Includes\Cafe;
use Src\Includes\FusionCharts;

$arrChartConfig = array(
    "chart" => array(
        "caption" => "V",
        //"numberSuffix" => "%",
        "gaugefillmix" => "{dark-20},{light+70},{dark-10}",
        "theme" => "fusion"
    ),

    "colorrange" => array(
        "color" => [
            [
                "minvalue"=> "0",
                "maxvalue"=> "20.0",
                "label"=> "Muito Baixo",
                "code"=> "#FE0606"
            ],
            [
                "minvalue" => "20.1",
                "maxvalue" => "40.0",
                "label" => "Baixo",
                "code" => "#F79301"
            ],
            [
                "minvalue" => "40.41",
                "maxvalue" => "60.0",
                "label" => "Médio",
                "code" => "#FDCF02"
            ],
            [
                "minvalue" => "60.01",
                "maxvalue" => "80.0",
                "label" => "Bom",
                "code" => "#018233"
            ]
        ]
    ),

    "pointers" => array(
        "pointer" => [
            [
                "value" => $busca["v"]
            ]
        ]
    )
);

$jsonEncodedData = json_encode($arrChartConfig);

$columnChart = new FusionCharts("hlineargauge", "V", "100%", 150, "v", "json", $jsonEncodedData);

$columnChart->render();
?>