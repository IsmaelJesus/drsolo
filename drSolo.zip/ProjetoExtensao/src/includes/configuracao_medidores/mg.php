<?php

namespace Src\Includes\Cafe;
use Src\Includes\FusionCharts;

$arrChartConfig = array(
    "chart" => array(
        "caption" => "Mg",
        //"numberSuffix" => "cmol c/dm³",
        "gaugefillmix" => "{dark-20},{light+70},{dark-10}",
        "theme" => "fusion"
    ),

    "colorrange" => array(
        "color" => [
            [
                "minvalue"=> "0",
                "maxvalue"=> "0.15",
                "label"=> "Muito Baixo",
                "code"=> "#FE0606"
            ],
            [
                "minvalue" => "0.16",
                "maxvalue" => "0.45",
                "label" => "Baixo",
                "code" => "#F79301"
            ],
            [
                "minvalue" => "0.46",
                "maxvalue" => "0.90",
                "label" => "Médio",
                "code" => "#FDCF02"
            ],
            [
                "minvalue" => "0.91",
                "maxvalue" => "1.50",
                "label" => "Bom",
                "code" => "#018233"
            ]
        ]
    ),

    "pointers" => array(
        "pointer" => [
            [
                "value" => $busca["mg"]
            ]
        ]
    )
);

$jsonEncodedData = json_encode($arrChartConfig);

$columnChart = new FusionCharts("hlineargauge", "Mg", "100%", 150, "mg", "json", $jsonEncodedData);

$columnChart->render();
?>