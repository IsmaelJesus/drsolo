<?php

namespace Src\Includes\Cafe;
use Src\Includes\FusionCharts;

$arrChartConfig = array(
    "chart" => array(
        "caption" => "Fe",
        //"numberSuffix" => "mg/dm3",
        "gaugefillmix" => "{dark-20},{light+70},{dark-10}",
        "theme" => "fusion"
    ),

    "colorrange" => array(
        "color" => [
            [
                "minvalue"=> "0",
                "maxvalue"=> "8.0",
                "label"=> "Muito Baixo",
                "code"=> "#FE0606"
            ],
            [
                "minvalue" => "9.0",
                "maxvalue" => "18.0",
                "label" => "Baixo",
                "code" => "#F79301"
            ],
            [
                "minvalue" => "19.0",
                "maxvalue" => "30.0",
                "label" => "Médio",
                "code" => "#FDCF02"
            ],
            [
                "minvalue" => "31.0",
                "maxvalue" => "45.0",
                "label" => "Bom",
                "code" => "#018233"
            ]
        ]
    ),

    "pointers" => array(
        "pointer" => [
            [
                "value" => $busca["fe"]
            ]
        ]
    )
);

$jsonEncodedData = json_encode($arrChartConfig);

$columnChart = new FusionCharts("hlineargauge", "Fe", "100%", 150, "fe", "json", $jsonEncodedData);

$columnChart->render();
?>