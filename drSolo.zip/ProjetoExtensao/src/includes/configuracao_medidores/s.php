<?php

namespace Src\Includes\Cafe;
use Src\Includes\FusionCharts;

$arrChartConfig = array(
    "chart" => array(
        "caption" => "S",
        //"numberSuffix" => "mg/dm3",
        "gaugefillmix" => "{dark-20},{light+70},{dark-10}",
        "theme" => "fusion"
    ),

    "colorrange" => array(
        "color" => [
            [
                "minvalue"=> "0",
                "maxvalue"=> "2",
                "label"=> "Muito Baixo",
                "code"=> "#FE0606"
            ],
            [
                "minvalue" => "2.1",
                "maxvalue" => "4",
                "label" => "Baixo",
                "code" => "#F79301"
            ],
            [
                "minvalue" => "5",
                "maxvalue" => "10",
                "label" => "Médio",
                "code" => "#FDCF02"
            ],
            [
                "minvalue" => "10.1",
                "maxvalue" => "12",
                "label" => "Bom",
                "code" => "#018233"
            ]
        ]
    ),

    "pointers" => array(
        "pointer" => [
            [
                "value" => $busca["s"]
            ]
        ]
    )
);

$jsonEncodedData = json_encode($arrChartConfig);

$columnChart = new FusionCharts("hlineargauge", "S", "100%", 150, "s", "json", $jsonEncodedData);

$columnChart->render();
?>