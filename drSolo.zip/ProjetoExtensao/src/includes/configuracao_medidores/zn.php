<?php

namespace Src\Includes\Cafe;
use Src\Includes\FusionCharts;

$arrChartConfig = array(
    "chart" => array(
        "caption" => "Zn",
        //"numberSuffix" => "mg/dm3",
        "gaugefillmix" => "{dark-20},{light+70},{dark-10}",
        "theme" => "fusion"
    ),

    "colorrange" => array(
        "color" => [
            [
                "minvalue"=> "0",
                "maxvalue"=> "0.4",
                "label"=> "Muito Baixo",
                "code"=> "#FE0606"
            ],
            [
                "minvalue" => "0.5",
                "maxvalue" => "0.9",
                "label" => "Baixo",
                "code" => "#F79301"
            ],
            [
                "minvalue" => "1.0",
                "maxvalue" => "1.5",
                "label" => "Médio",
                "code" => "#FDCF02"
            ],
            [
                "minvalue" => "1.6",
                "maxvalue" => "2.2",
                "label" => "Bom",
                "code" => "#018233"
            ]
        ]
    ),

    "pointers" => array(
        "pointer" => [
            [
                "value" => $busca["zn"]
            ]
        ]
    )
);

$jsonEncodedData = json_encode($arrChartConfig);

$columnChart = new FusionCharts("hlineargauge", "Zn", "100%", 150, "zn", "json", $jsonEncodedData);

$columnChart->render();
?>