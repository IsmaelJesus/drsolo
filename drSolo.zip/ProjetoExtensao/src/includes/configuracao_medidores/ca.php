<?php

namespace Src\Includes\Cafe;
use Src\Includes\FusionCharts;

$arrChartConfig = array(
    "chart" => array(
        "caption" => "Ca",
        //"numberSuffix" => "mg/dm3",
        "gaugefillmix" => "{dark-20},{light+70},{dark-10}",
        "theme" => "fusion"
    ),

    "colorrange" => array(
        "color" => [
            [
                "minvalue"=> "0",
                "maxvalue"=> "0.4",
                "label"=> "Muito Baixo",
                "code"=> "#FE0606"
            ],
            [
                "minvalue" => "0.41",
                "maxvalue" => "1.2",
                "label" => "Baixo",
                "code" => "#F79301"
            ],
            [
                "minvalue" => "1.21",
                "maxvalue" => "2.40",
                "label" => "Médio",
                "code" => "#FDCF02"
            ],
            [
                "minvalue" => "2.41",
                "maxvalue" => "4.0",
                "label" => "Bom",
                "code" => "#018233"
            ]
        ]
    ),

    "pointers" => array(
        "pointer" => [
            [
                "value" => $busca["ca"]
            ]
        ]
    )
);

$jsonEncodedData = json_encode($arrChartConfig);

$columnChart = new FusionCharts("hlineargauge", "Ca", "100%", 150, "ca", "json", $jsonEncodedData);

$columnChart->render();
?>