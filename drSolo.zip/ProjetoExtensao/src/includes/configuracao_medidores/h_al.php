<?php

namespace Src\Includes\Cafe;
use Src\Includes\FusionCharts;

$arrChartConfig = array(
    "chart" => array(
        "caption" => "H + Al",
        //"numberSuffix" => "mg/dm3",
        "gaugefillmix" => "{dark-20},{light+70},{dark-10}",
        "theme" => "fusion"
    ),

    "colorrange" => array(
        "color" => [
            [
                "minvalue"=> "0",
                "maxvalue"=> "1",
                "label"=> "Muito Baixo",
                "code"=> "#FE0606"
            ],
            [
                "minvalue" => "1.01",
                "maxvalue" => "2.5",
                "label" => "Baixo",
                "code" => "#F79301"
            ],
            [
                "minvalue" => "2.51",
                "maxvalue" => "5.0",
                "label" => "Médio",
                "code" => "#FDCF02"
            ],
            [
                "minvalue" => "5.01",
                "maxvalue" => "9.0",
                "label" => "Bom",
                "code" => "#018233"
            ]
        ]
    ),

    "pointers" => array(
        "pointer" => [
            [
                "value" => $busca["h_al"]
            ]
        ]
    )
);

$jsonEncodedData = json_encode($arrChartConfig);

$columnChart = new FusionCharts("hlineargauge", "Hal", "100%", 150, "h_al", "json", $jsonEncodedData);

$columnChart->render();
?>