-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 04-Nov-2019 às 01:21
-- Versão do servidor: 10.4.6-MariaDB
-- versão do PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `drsolo`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `analises`
--

CREATE TABLE `analises` (
  `cod_analise` int(11) NOT NULL,
  `cod_cliente` int(11) NOT NULL,
  `cod_lab` int(11) NOT NULL,
  `data_analise` date NOT NULL,
  `ph_agua` float(9,2) NOT NULL,
  `ph_cacl2` float(9,2) DEFAULT NULL,
  `m_o` float(9,2) NOT NULL,
  `p` float(9,2) NOT NULL,
  `k` float(9,2) NOT NULL,
  `ca` float(9,2) NOT NULL,
  `mg` float(9,2) NOT NULL,
  `s` float(9,2) NOT NULL,
  `zn` float(9,2) NOT NULL,
  `b` float(9,2) NOT NULL,
  `cu` float(9,2) NOT NULL,
  `fe` float(9,2) NOT NULL,
  `mn` float(9,2) NOT NULL,
  `al` float(9,2) NOT NULL,
  `argila` int(4) NOT NULL,
  `silte` int(4) NOT NULL,
  `areia` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `analises`
--

INSERT INTO `analises` (`cod_analise`, `cod_cliente`, `cod_lab`, `data_analise`, `ph_agua`, `ph_cacl2`, `m_o`, `p`, `k`, `ca`, `mg`, `s`, `zn`, `b`, `cu`, `fe`, `mn`, `al`, `argila`, `silte`, `areia`) VALUES
(1, 1, 1, '2016-10-14', 4.00, NULL, 26.00, 25.00, 3.00, 26.00, 11.00, 14.00, 3.00, 6.00, 1.00, 103.00, 4.00, 0.00, 265, 177, 558);

-- --------------------------------------------------------

--
-- Estrutura da tabela `clientes`
--

CREATE TABLE `clientes` (
  `cod_cliente` int(11) NOT NULL,
  `nome` varchar(100) CHARACTER SET utf8 NOT NULL,
  `email` varchar(60) NOT NULL,
  `senha` varchar(16) NOT NULL,
  `telefone` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `clientes`
--

INSERT INTO `clientes` (`cod_cliente`, `nome`, `email`, `senha`, `telefone`) VALUES
(1, 'admin', 'admin@admin.com', 'admin', '38999999999');

-- --------------------------------------------------------

--
-- Estrutura da tabela `laboratorio`
--

CREATE TABLE `laboratorio` (
  `cod_lab` int(11) NOT NULL,
  `nome` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `telefone` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `laboratorio`
--

INSERT INTO `laboratorio` (`cod_lab`, `nome`, `email`, `telefone`) VALUES
(1, 'Campo', 'campo@campo.com', '38999999999');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `analises`
--
ALTER TABLE `analises`
  ADD PRIMARY KEY (`cod_analise`),
  ADD KEY `fk_cliente` (`cod_cliente`),
  ADD KEY `fk_lab` (`cod_lab`);

--
-- Índices para tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`cod_cliente`);

--
-- Índices para tabela `laboratorio`
--
ALTER TABLE `laboratorio`
  ADD PRIMARY KEY (`cod_lab`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `analises`
--
ALTER TABLE `analises`
  MODIFY `cod_analise` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `clientes`
--
ALTER TABLE `clientes`
  MODIFY `cod_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `laboratorio`
--
ALTER TABLE `laboratorio`
  MODIFY `cod_lab` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `analises`
--
ALTER TABLE `analises`
  ADD CONSTRAINT `fk_cliente` FOREIGN KEY (`cod_cliente`) REFERENCES `clientes` (`cod_cliente`),
  ADD CONSTRAINT `fk_lab` FOREIGN KEY (`cod_lab`) REFERENCES `laboratorio` (`cod_lab`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
