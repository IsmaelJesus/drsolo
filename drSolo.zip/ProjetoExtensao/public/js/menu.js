$('#sidebarCollapse').on('click', function () {
    $('.sidebar').toggleClass('active');
});

$(window).on('resize', function(){
    var win = $(this); //this = window
    if (win.width() >= 1024) {
        $('.sidebar').removeClass('active');
    }
});

$(document).ready(function () {
    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
        $(this).toggleClass('active');
    });
});