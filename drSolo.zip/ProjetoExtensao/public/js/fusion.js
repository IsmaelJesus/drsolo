$("#phAgua").insertFusionCharts({
  type: "hlineargauge",
  width: "100%",
  height: "100%",
  dataFormat: "json",
  dataSource: {
    chart: {
    //caption: "Avaliação do Ph",
    //subcaption: "Pressure Reading",
    //numbersuffix: "acidez",
    gaugefillmix: "{dark-20},{light+70},{dark-10}",
    theme: "fusion"
  },
  colorrange: {
    color: [
      {
        minvalue: "0",
        maxvalue: "5",
        label: "Baixo",
        code: "#F2726F"
      },
      {
        minvalue: "5",
        maxvalue: "6",
        label: "Médio",
        code: "#FFC533"
      },
      {
        minvalue: "6",
        maxvalue: "8",
        label: "Bom",
        code: "#62B58F"
      }
    ]
  },
  pointers: {
    pointer: [
      {
        value: "4.7"
      }
    ]
  }
  }
});


$("#gaugeMo").insertFusionCharts({
  type: "hlineargauge",
  width: "100%",
  height: "100%",
  dataFormat: "json",
  dataSource: {
    chart: {
    //caption: "Avaliação do Alumínio",
    //subcaption: "Pressure Reading",
    //numbersuffix: "acidez",
    gaugefillmix: "{dark-20},{light+70},{dark-10}",
    theme: "fusion"
  },
  colorrange: {
    color: [
      {
        minvalue: "0",
        maxvalue: "0.5",
        label: "Baixo",
        code: "#F2726F"
      },
      {
        minvalue: "0.4",
        maxvalue: "0.9",
        label: "Médio",
        code: "#FFC533"
      },
      {
        minvalue: "1",
        maxvalue: "2",
        label: "Bom",
        code: "#62B58F"
      }
    ]
  },
  pointers: {
    pointer: [
      {
        value: "2.4"
      }
    ]
  }
  }
});
