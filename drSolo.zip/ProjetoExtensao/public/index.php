<?php

header("Content-Type: text/html; charset=utf8");
require_once ("../config/config.php");
require_once ("../src/vendor/autoload.php");

$view = new App\Dispatch();

